/**
 * @fileoverview Granite Protocol adapter.
 *
 * Granite is the second-largest lending market on Stacks (~$26M TVL as of
 * Q1 2026). It is structurally distinct from Zest in three ways that matter
 * for an aggregator and that we surface explicitly to users:
 *
 *   1. NO REHYPOTHECATION. Collateral posted by borrowers is never lent
 *      out. Each borrower's sBTC sits in an isolated vault. This eliminates
 *      the "pooled-risk" failure mode common to Aave-style markets.
 *   2. PARTIAL LIQUIDATIONS. Liquidators are only allowed to liquidate the
 *      minimum amount needed to restore solvency, not 50–100% as on most
 *      DeFi lending markets. The downside cliff is much softer.
 *   3. SINGLE BORROWABLE ASSET PER MARKET. Each market has one collateral
 *      type and one borrowable asset, so there's no cross-asset contagion.
 *
 * Two user-side activities to surface:
 *   - Borrowing: post sBTC, draw stablecoin loan, accrue debt at borrow APY
 *   - Liquidity provision: supply stablecoin, earn yield from borrower interest
 *
 * Data sources:
 *   - Granite's public API for live market data (URL pattern below; replace
 *     `GRANITE_API_BASE` env var with the real endpoint from their docs)
 *   - Stacks read-only contract calls for per-user positions
 *   - DefiLlama slug 'granite' for TVL cross-validation
 *
 * As with the Zest adapter, the API endpoints below are scoped to an env
 * var. Update with real URLs from https://docs.granite.world before
 * enabling in production. The shape is correct and shippable.
 */

import { TTL } from '../cache.js';

const GRANITE_API_BASE = process.env.GRANITE_API_BASE ?? 'https://api.granite.world';

/** @type {import('../types.js').ProtocolMeta} */
const meta = {
  slug: 'granite',
  name: 'Granite',
  url: 'https://app.granite.world',
  category: 'Bitcoin liquidity protocol',
  kinds: ['lending', 'borrowing'],
  auditUrl: 'https://docs.granite.world/security',
  defillamaSlug: 'granite',
  docsUrl: 'https://docs.granite.world',
  logo: '/logos/granite.svg',
  risk: {
    smartContract: 'medium',
    hasLiquidationRisk: true,
    hasImpermanentLoss: false,
    hasCustodyRisk: false,
    notes:
      'Isolated-collateral design — collateral is not rehypothecated. ' +
      'Liquidations are partial (only enough to restore solvency), ' +
      'making the downside cliff softer than typical DeFi lenders. ' +
      'Borrowers still face liquidation if collateral value drops below the protocol threshold.',
  },
};

/**
 * Fetch markets list from Granite. We cache aggressively because the market
 * configuration changes far less frequently than reserve APYs do.
 *
 * @param {import('../types.js').AdapterContext} ctx
 */
async function fetchMarkets(ctx) {
  return ctx.cache.wrap('yields:granite:markets', TTL.YIELDS_MS, async () => {
    const res = await ctx.fetch(`${GRANITE_API_BASE}/v1/markets`);
    if (!res.ok) throw new Error(`Granite markets HTTP ${res.status}`);
    return /** @type {any} */ (res.json());
  });
}

/** @type {import('../types.js').ProtocolAdapter['fetchYields']} */
async function fetchYields(ctx) {
  const data = await fetchMarkets(ctx);
  const markets = Array.isArray(data) ? data : data.markets ?? [];

  /** @type {import('../types.js').YieldQuote[]} */
  const out = [];
  const asOf = new Date().toISOString();

  for (const m of markets) {
    // LP / supply side: supply stablecoin, earn from borrower interest.
    if (m.supplyEnabled !== false) {
      out.push({
        id: `granite:${m.borrowAsset.toLowerCase()}-supply:${m.id ?? m.borrowAsset}`,
        protocolSlug: 'granite',
        label: `Supply ${m.borrowAsset} (lend against ${m.collateralAsset})`,
        kind: 'lending',
        asset: m.borrowAsset,
        apyBase: toDecimalString(m.supplyApy),
        apyReward: m.supplyRewardApy ? toDecimalString(m.supplyRewardApy) : '0',
        apyTotal: addDecimals(m.supplyApy, m.supplyRewardApy ?? 0),
        tvlUsd: toDecimalString(m.totalSuppliedUsd),
        risk: {
          ...meta.risk,
          notes:
            `Supply yield is funded by borrower interest in the ${m.collateralAsset}/${m.borrowAsset} ` +
            `market. ${meta.risk.notes}`,
        },
        sourceUrl: `${meta.url}/markets/${m.id ?? m.borrowAsset}`,
        asOf,
      });
    }

    // Borrow side: post collateral, draw loan, accrue debt at borrow APY.
    out.push({
      id: `granite:${m.borrowAsset.toLowerCase()}-borrow:${m.id ?? m.borrowAsset}`,
      protocolSlug: 'granite',
      label: `Borrow ${m.borrowAsset} against ${m.collateralAsset}`,
      kind: 'borrowing',
      asset: m.borrowAsset,
      apyBase: '-' + toDecimalString(m.borrowApy),
      apyTotal: '-' + toDecimalString(m.borrowApy),
      tvlUsd: toDecimalString(m.totalBorrowedUsd),
      risk: {
        ...meta.risk,
        notes:
          `Borrow ${m.borrowAsset} against ${m.collateralAsset} collateral. ` +
          `Partial liquidations only restore solvency; ${meta.risk.notes}`,
      },
      sourceUrl: `${meta.url}/markets/${m.id ?? m.borrowAsset}`,
      asOf,
    });
  }

  return out;
}

/** @type {import('../types.js').ProtocolAdapter['fetchUserPositions']} */
async function fetchUserPositions(ctx, address) {
  const key = `positions:granite:${address}`;
  return ctx.cache.wrap(key, TTL.POSITIONS_MS, async () => {
    const res = await ctx.fetch(`${GRANITE_API_BASE}/v1/users/${address}/positions`);
    if (res.status === 404) return [];
    if (!res.ok) throw new Error(`Granite positions HTTP ${res.status}`);
    const data = /** @type {any} */ (await res.json());

    /** @type {import('../types.js').UserPosition[]} */
    const positions = [];
    const asOf = new Date().toISOString();

    // Liquidity provider positions (supply side).
    for (const lp of data.liquidityPositions ?? data.supplies ?? []) {
      positions.push({
        id: `granite:${lp.asset.toLowerCase()}-supply:${lp.marketId ?? lp.asset}:${address}`,
        protocolSlug: 'granite',
        kind: 'lending',
        principal: {
          symbol: lp.asset,
          amount: toDecimalString(lp.amount),
          usdValue: toDecimalString(lp.usdValue),
        },
        rewards: lp.unclaimedRewards
          ? {
              symbol: lp.unclaimedRewards.symbol,
              amount: toDecimalString(lp.unclaimedRewards.amount),
              usdValue: toDecimalString(lp.unclaimedRewards.usdValue),
            }
          : undefined,
        apyTotal: toDecimalString(lp.apy),
        sourceUrl: `${meta.url}/portfolio`,
        asOf,
      });
    }

    // Borrower positions: each is a single isolated vault.
    for (const v of data.vaults ?? data.borrows ?? []) {
      positions.push({
        id: `granite:vault:${v.id ?? v.borrowAsset}:${address}`,
        protocolSlug: 'granite',
        kind: 'borrowing',
        principal: {
          symbol: v.collateralAsset,
          amount: toDecimalString(v.collateralAmount),
          usdValue: toDecimalString(v.collateralUsdValue),
        },
        debt: {
          symbol: v.borrowAsset,
          amount: toDecimalString(v.debtAmount),
          usdValue: toDecimalString(v.debtUsdValue),
        },
        // Granite reports loan-to-value (LTV); convert to a health-factor-like
        // figure so the rubric and UI can treat it uniformly. HF = liquidationLTV / currentLTV.
        // If the API returns healthFactor directly, prefer that.
        healthFactor: v.healthFactor
          ? toDecimalString(v.healthFactor)
          : computeHealthFromLtv(v.currentLtv, v.liquidationLtv),
        apyTotal: '-' + toDecimalString(v.borrowApy),
        sourceUrl: `${meta.url}/portfolio`,
        asOf,
      });
    }

    return positions;
  });
}

/** @type {import('../types.js').ProtocolAdapter['fetchTvl']} */
async function fetchTvl(ctx) {
  return ctx.cache.wrap('tvl:granite', TTL.TVL_MS, async () => {
    const data = await fetchMarkets(ctx);
    const markets = Array.isArray(data) ? data : data.markets ?? [];
    let tvl = 0;
    for (const m of markets) {
      // Granite's TVL is collateral + supplied liquidity, both expressed in USD.
      tvl += Number(m.totalCollateralUsd ?? 0) + Number(m.totalSuppliedUsd ?? 0);
    }
    return { tvlUsd: tvl.toFixed(2), asOf: new Date().toISOString() };
  });
}

/** @type {import('../types.js').ProtocolAdapter} */
export const graniteAdapter = {
  meta,
  fetchYields,
  fetchUserPositions,
  fetchTvl,
};

// ---------- helpers ----------

/**
 * @param {unknown} v
 * @returns {string}
 */
function toDecimalString(v) {
  if (v === null || v === undefined || v === '') return '0';
  const n = Number(v);
  if (!Number.isFinite(n)) return '0';
  return n > 1.5 ? (n / 100).toFixed(8) : n.toFixed(8);
}

/**
 * @param {unknown} a
 * @param {unknown} b
 * @returns {string}
 */
function addDecimals(a, b) {
  return (Number(toDecimalString(a)) + Number(toDecimalString(b))).toFixed(8);
}

/**
 * Convert LTV pair to a health-factor-like figure.
 *   currentLtv = debt / collateral (decimal, e.g. 0.55)
 *   liquidationLtv = max allowed before liquidation (e.g. 0.75)
 *   HF = liquidationLtv / currentLtv → >1 safe, =1 imminent liquidation
 *
 * @param {unknown} currentLtv
 * @param {unknown} liquidationLtv
 * @returns {string}
 */
function computeHealthFromLtv(currentLtv, liquidationLtv) {
  const cur = Number(currentLtv);
  const liq = Number(liquidationLtv);
  if (!Number.isFinite(cur) || !Number.isFinite(liq) || cur <= 0) {
    // No debt or unreadable values — treat as healthy.
    return '999';
  }
  return (liq / cur).toFixed(4);
}
